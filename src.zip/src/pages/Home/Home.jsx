import React from 'react'
import AbusiveDetect from '../../components/AbusiveDetect/AbusiveDetect'
import Navbar from '../../components/Navbar/Navbar'

function Home() {
  return (
    <>
      {/* <Navbar/> */}
      <AbusiveDetect/>
    </>
  )
}

export default Home
